check = float(input("How much was your check?: "))

print("15% tip =", round(check*1.15, 2))
print("18% tip =", round(check * 1.18, 2))
print("20% tip =", round(check * 1.20, 2))
